#ifndef __LECTURE_H__
#define __LECTURE_H__

#include "affichage.h"

/* remplie laby, depart et arrivee avec les valeurs de nomFichier*/
int construitLabyrinthe( int laby[TAILLE_X][TAILLE_Y], int depart[2], int arrivee[2], char * nomFichier );

#endif
