#include "lecture.h"
#include <stdlib.h>
#include <stdio.h>

int construitLabyrinthe( int laby[TAILLE_X][TAILLE_Y], int depart[2], int arrivee[2], char * nomFichier )
{
    FILE* fichier;
    if(!(fichier = fopen(nomFichier, "r")))
        return 0;
    
    fscanf(fichier, "%d%d%d%d", &depart[0], &depart[1], &arrivee[0], &arrivee[1]);

    

    for(int i = 0; i < TAILLE_Y; i++)
    {
        for(int j = 0; j < TAILLE_X; j++) 
        {
            fscanf(fichier, "%d", &laby[j][i]);
        }
    }
    
    fclose(fichier);
    return 1;
}

