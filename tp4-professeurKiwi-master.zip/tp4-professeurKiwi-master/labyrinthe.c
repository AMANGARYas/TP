#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "affichage.h"
#include "lecture.h"

#define FREQ_AFF 15

void deplacement(int*x, int*y, int d)
{
    /*si l'on cherche à utiliser les case voisines d'une case sur le bord du plateau,
    on va faire un débordement de tableau, risque de segmentation fault*/
    
    switch(d)
    {
    case 0:
        *y+=1;
        break;
    case 1:
        *x+=1;
        break;
    case 2:
        *y-=1;
        break;
    case 3:
        *x-=1;
        break;
    }
        
}

bool parcourirLabyrinthe(int laby[TAILLE_X][TAILLE_Y], int depart[2], int arrivee[2])
{
    int r = 1;
    bool arriveeAtteinte = 0;
    bool sortiePossible = 1;
    laby[depart[0]][depart[1]] = r;
    
    //tant que la sortie n'est pas atteinte et qu'on a pas constaté que l'on est bloqué
    while(!arriveeAtteinte && sortiePossible)
    {
        //on ne sait pas si une sortie peut encore exister
        sortiePossible = 0;
        //parcours du tableau
        for(int i =1; i < TAILLE_X - 1 && !arriveeAtteinte; i++)
        {
            for(int j = 1; j < TAILLE_Y - 1 && !arriveeAtteinte; j++)
            {
                //pour chaque case de valeur r, on rend ses voisines libres égales à r+1, dans ce cas, une sortie peut encore exister
                //on test si on a atteint la sortie
                if(laby[i][j] == r)
                {
                    for(int d = 0; d <=3; d++) 
                    {
                        int x = i, y = j;
                        deplacement(&x, &y, d);
                        
                        if(laby[x][y] == 0)
                        {
                            laby[x][y] = r + 1;
                            sortiePossible = 1;
                        }
                        
                        if( x == arrivee[0] && y == arrivee[1])
                            arriveeAtteinte = 1;
                    }
                } 
            }
        }
        //on affiche le labyrinthe et avance d'un pas
        afficheLabyrinthe(laby, depart, arrivee, FREQ_AFF);
        r++;
    }

    return sortiePossible;
}

bool parcourRecur(int laby[TAILLE_X][TAILLE_Y], int depart[2], int arrivee[2], int coorX, int coorY, int r)
{
    bool sortieTrouvee = 0;
    for(int d = 0; d <= 3; d++)
    {
        int x = coorX, y = coorY;
        deplacement(&x, &y, d);
        if(laby[x][y] > r+1 || laby[x][y] == 0)
        {
            laby[x][y] = r+1;
            if(x == arrivee[0] && y == arrivee[1])
            {
                sortieTrouvee = 1;
                break;
            }
            afficheLabyrinthe(laby, depart, arrivee, 2);
            sortieTrouvee = (sortieTrouvee || parcourRecur(laby, depart, arrivee, x, y, r + 1));
            
        }
    }
    return sortieTrouvee;
}

bool parcourirLabyrintheRecursif(int laby[TAILLE_X][TAILLE_Y], int depart[2], int arrivee[2])
{
    laby[depart[0]][depart[1]] = 1;
    bool sortieTrouvee = 0;

    for(int d = 0; d <= 3; d++)
    {
        int x = depart[0], y = depart[1];
        deplacement(&x, &y, d);
        if(laby[x][y] == 0)
        {
            laby[x][y] = 2;
            if(x == arrivee[0] && y == arrivee[1])
            {
                sortieTrouvee = 1;
                break;
            }
            afficheLabyrinthe(laby, depart, arrivee, 2);
            sortieTrouvee = sortieTrouvee || parcourRecur(laby, depart, arrivee, x, y, 2);
            
        }
    }

    return sortieTrouvee;
}



bool remonterChemain(int laby[TAILLE_X][TAILLE_Y], int depart[2], int arrivee[2])
{
    int coorX = arrivee[0], coorY = arrivee[1];
    int r = laby[coorX][coorY];
    bool precedentTrouve = 1;
    laby[coorX][coorY] = -2;
    
    //tant qu'on est pas à la case d'arrivée et qu'il n'y a pas d'erreurs
    while(r > 1 && precedentTrouve)
    {
        //a priori, on a pas trouvé un précédent, ce qui peut provoquer une erreur
        precedentTrouve = 0;
        //pour chaque direction, si on trouve un précédent, il devient la case en cours, et on arrête de vérifier les dirrections.
        for(int d = 0; d <=3; d++) 
        {
            int x = coorX, y = coorY;
            deplacement(&x, &y, d);
            
            if(laby[x][y] == r - 1)
            {
                laby[x][y] = -2;
                coorX = x;
                coorY = y;
                precedentTrouve = 1;
                break;
            }
        }
        //on affiche le labyrinthe et avance d'un pas
        afficheLabyrinthe(laby, depart, arrivee, FREQ_AFF);
        r--;
    }
    return precedentTrouve;
} 

//remplace les valeurs positives (case parcourues) par 0 (case libre);
void netoyerLabyrinthe(int laby[TAILLE_X][TAILLE_Y])
{
    for(int i = 0; i < TAILLE_X; i++)
        for(int j = 0; j < TAILLE_Y; j++)
            if(laby[i][j] > 0)
                laby[i][j] = 0;
}

int main()
{
    int labyrinthe[TAILLE_X][TAILLE_Y];
    int depart[2], arrivee[2];
    construitLabyrinthe(labyrinthe, depart, arrivee, "laby3.txt");
    
    if(!initAffichage())
    {
        printf("aïeaïeaïe, ça marche pas\n");
        return EXIT_FAILURE;
    }
    //affichage à vide
    afficheLabyrinthe(labyrinthe, depart, arrivee, 0);    
    
    //exploration
    bool sortieExiste = parcourirLabyrintheRecursif(labyrinthe, depart, arrivee);
    if(!sortieExiste)
        printf("Aucune sortie possible\n");
    
    afficheLabyrinthe(labyrinthe, depart, arrivee, 0);
    
    if(sortieExiste)
    {
        //retour sur nos pas
        if(!remonterChemain(labyrinthe, depart, arrivee))
        {
            printf("ERREUR: remonterChemain n'a pas trouvé de retour!");
            return EXIT_FAILURE;
        }
        afficheLabyrinthe(labyrinthe, depart, arrivee, 0);

        //nétoyage
        netoyerLabyrinthe(labyrinthe);
        afficheLabyrinthe(labyrinthe, depart, arrivee, 0);
    }
}
